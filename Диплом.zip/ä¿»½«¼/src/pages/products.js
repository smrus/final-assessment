import Header from  '../components/app-header';
import Cards from '../components/cards';


function Products() {
    return (
        <div>
            <Header />
            <Cards />
        </div>
    );
}
  
export default Products;