import '../components/registrartion/reg.css';
import Autorization from '../components/autorization/auto';

function Main() {
  return (
    <div className="Main">
      <Autorization />
    </div>
  );
}
  
export default Main;