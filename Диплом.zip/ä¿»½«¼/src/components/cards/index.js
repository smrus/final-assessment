import Cards from './cards';

export default Cards;