import Registration from "./reg";

export default Registration;