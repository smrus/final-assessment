import Autorization from "./auto";

export default Autorization;