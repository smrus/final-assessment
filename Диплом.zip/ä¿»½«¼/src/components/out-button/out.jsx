import './out.css';

function Out() {
    return (
        <button className='Out-btn'>Выйти</button>
    )
}

export default Out;