import Out from './out';

export default Out;